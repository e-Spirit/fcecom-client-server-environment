# IO.Swagger.Model.Product
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Label** | **string** | The localized Label | 
**Extract** | **string** | Product Extract | [optional] 
**Image** | **string** | Image URL | [optional] 
**Thumbnail** | **string** | Thumbnail URL | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

