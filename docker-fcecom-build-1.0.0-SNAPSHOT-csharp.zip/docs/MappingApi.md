# IO.Swagger.Api.MappingApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**LookupUrlGet**](MappingApi.md#lookupurlget) | **GET** /lookup-url | Returns an Identifier for a given Storefront URL
[**StorefrontUrlGet**](MappingApi.md#storefronturlget) | **GET** /storefront-url | Returns a Storefront URL

<a name="lookupurlget"></a>
# **LookupUrlGet**
> InlineResponse200 LookupUrlGet (string url)

Returns an Identifier for a given Storefront URL

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class LookupUrlGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new MappingApi();
            var url = url_example;  // string | A Storefront URL

            try
            {
                // Returns an Identifier for a given Storefront URL
                InlineResponse200 result = apiInstance.LookupUrlGet(url);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MappingApi.LookupUrlGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **url** | **string**| A Storefront URL | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="storefronturlget"></a>
# **StorefrontUrlGet**
> InlineResponse2001 StorefrontUrlGet (string type, string id, string lang = null)

Returns a Storefront URL

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class StorefrontUrlGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new MappingApi();
            var type = type_example;  // string | Page Type
            var id = id_example;  // string | Unique Identifier
            var lang = lang_example;  // string | The language to localize the label (optional) 

            try
            {
                // Returns a Storefront URL
                InlineResponse2001 result = apiInstance.StorefrontUrlGet(type, id, lang);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MappingApi.StorefrontUrlGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type** | **string**| Page Type | 
 **id** | **string**| Unique Identifier | 
 **lang** | **string**| The language to localize the label | [optional] 

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
