# IO.Swagger.Api.ContentsApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ContentContentIdDelete**](ContentsApi.md#contentcontentiddelete) | **DELETE** /content/{contentId} | Rename and/or move a Content Page
[**ContentContentIdPut**](ContentsApi.md#contentcontentidput) | **PUT** /content/{contentId} | Rename and/or move a Content Page
[**ContentPost**](ContentsApi.md#contentpost) | **POST** /content | Create a new Content Page
[**ContentsContentIdsGet**](ContentsApi.md#contentscontentidsget) | **GET** /contents/{contentIds} | Returns a list of Content Pages by IDs
[**ContentsGet**](ContentsApi.md#contentsget) | **GET** /contents | Returns a list of Content Pages
[**ContentsHead**](ContentsApi.md#contentshead) | **HEAD** /contents | Supports Content Report if exists

<a name="contentcontentiddelete"></a>
# **ContentContentIdDelete**
> void ContentContentIdDelete (string contentId, string lang = null)

Rename and/or move a Content Page

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ContentContentIdDeleteExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new ContentsApi();
            var contentId = contentId_example;  // string | 
            var lang = lang_example;  // string | The language to localize the label (optional) 

            try
            {
                // Rename and/or move a Content Page
                apiInstance.ContentContentIdDelete(contentId, lang);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ContentsApi.ContentContentIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **contentId** | **string**|  | 
 **lang** | **string**| The language to localize the label | [optional] 

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="contentcontentidput"></a>
# **ContentContentIdPut**
> void ContentContentIdPut (Content body, string contentId, string lang = null)

Rename and/or move a Content Page

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ContentContentIdPutExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new ContentsApi();
            var body = new Content(); // Content | 
            var contentId = contentId_example;  // string | 
            var lang = lang_example;  // string | The language to localize the label (optional) 

            try
            {
                // Rename and/or move a Content Page
                apiInstance.ContentContentIdPut(body, contentId, lang);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ContentsApi.ContentContentIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Content**](Content.md)|  | 
 **contentId** | **string**|  | 
 **lang** | **string**| The language to localize the label | [optional] 

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="contentpost"></a>
# **ContentPost**
> InlineResponse200 ContentPost (Content body, string lang = null)

Create a new Content Page

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ContentPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new ContentsApi();
            var body = new Content(); // Content | 
            var lang = lang_example;  // string | The language to localize the label (optional) 

            try
            {
                // Create a new Content Page
                InlineResponse200 result = apiInstance.ContentPost(body, lang);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ContentsApi.ContentPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Content**](Content.md)|  | 
 **lang** | **string**| The language to localize the label | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="contentscontentidsget"></a>
# **ContentsContentIdsGet**
> List<Content> ContentsContentIdsGet (List<string> contentIds, string lang = null)

Returns a list of Content Pages by IDs

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ContentsContentIdsGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new ContentsApi();
            var contentIds = new List<string>(); // List<string> | Get one or more Content Pages by content.id (comma-separated)
            var lang = lang_example;  // string | The language to localize the label (optional) 

            try
            {
                // Returns a list of Content Pages by IDs
                List&lt;Content&gt; result = apiInstance.ContentsContentIdsGet(contentIds, lang);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ContentsApi.ContentsContentIdsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **contentIds** | [**List&lt;string&gt;**](string.md)| Get one or more Content Pages by content.id (comma-separated) | 
 **lang** | **string**| The language to localize the label | [optional] 

### Return type

[**List<Content>**](Content.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="contentsget"></a>
# **ContentsGet**
> List<Content> ContentsGet (string q = null, string lang = null, int? page = null)

Returns a list of Content Pages

A pageable list of Content Pages. Could be filtered.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ContentsGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new ContentsApi();
            var q = q_example;  // string | Fulltext search query string (optional) 
            var lang = lang_example;  // string | The language to localize the label (optional) 
            var page = 56;  // int? | Specific result page (optional)  (default to 1)

            try
            {
                // Returns a list of Content Pages
                List&lt;Content&gt; result = apiInstance.ContentsGet(q, lang, page);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ContentsApi.ContentsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **string**| Fulltext search query string | [optional] 
 **lang** | **string**| The language to localize the label | [optional] 
 **page** | **int?**| Specific result page | [optional] [default to 1]

### Return type

[**List<Content>**](Content.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="contentshead"></a>
# **ContentsHead**
> void ContentsHead ()

Supports Content Report if exists

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ContentsHeadExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new ContentsApi();

            try
            {
                // Supports Content Report if exists
                apiInstance.ContentsHead();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ContentsApi.ContentsHead: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
