# IO.Swagger.Api.ProductsApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductsGet**](ProductsApi.md#productsget) | **GET** /products | Returns a list of Products
[**ProductsProductIdsGet**](ProductsApi.md#productsproductidsget) | **GET** /products/{productIds} | Returns a list of Products by IDs

<a name="productsget"></a>
# **ProductsGet**
> List<Product> ProductsGet (string categoryId = null, string q = null, string lang = null, int? page = null)

Returns a list of Products

A pageable list of products. Could be filtered.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductsGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new ProductsApi();
            var categoryId = categoryId_example;  // string | Filter by category.id (optional) 
            var q = q_example;  // string | Fulltext search query string (optional) 
            var lang = lang_example;  // string | The language to localize the label (optional) 
            var page = 56;  // int? | Specific result page (optional)  (default to 1)

            try
            {
                // Returns a list of Products
                List&lt;Product&gt; result = apiInstance.ProductsGet(categoryId, q, lang, page);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductsApi.ProductsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **string**| Filter by category.id | [optional] 
 **q** | **string**| Fulltext search query string | [optional] 
 **lang** | **string**| The language to localize the label | [optional] 
 **page** | **int?**| Specific result page | [optional] [default to 1]

### Return type

[**List<Product>**](Product.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="productsproductidsget"></a>
# **ProductsProductIdsGet**
> List<Product> ProductsProductIdsGet (List<string> productIds, string lang = null)

Returns a list of Products by IDs

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductsProductIdsGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new ProductsApi();
            var productIds = new List<string>(); // List<string> | Get one or more Products by product.id (comma-separated)
            var lang = lang_example;  // string | The language to localize the label (optional) 

            try
            {
                // Returns a list of Products by IDs
                List&lt;Product&gt; result = apiInstance.ProductsProductIdsGet(productIds, lang);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductsApi.ProductsProductIdsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productIds** | [**List&lt;string&gt;**](string.md)| Get one or more Products by product.id (comma-separated) | 
 **lang** | **string**| The language to localize the label | [optional] 

### Return type

[**List<Product>**](Product.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
