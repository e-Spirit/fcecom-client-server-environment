# Swagger\Client\MappingApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**lookupUrlGet**](MappingApi.md#lookupurlget) | **GET** /lookup-url | Returns an Identifier for a given Storefront URL
[**storefrontUrlGet**](MappingApi.md#storefronturlget) | **GET** /storefront-url | Returns a Storefront URL

# **lookupUrlGet**
> \Swagger\Client\Model\InlineResponse200 lookupUrlGet($url)

Returns an Identifier for a given Storefront URL

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
// Configure HTTP basic authorization: basicAuth
$config = Swagger\Client\Configuration::getDefaultConfiguration()
              ->setUsername('YOUR_USERNAME')
              ->setPassword('YOUR_PASSWORD');


$apiInstance = new Swagger\Client\Api\MappingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$url = "url_example"; // string | A Storefront URL

try {
    $result = $apiInstance->lookupUrlGet($url);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MappingApi->lookupUrlGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **url** | **string**| A Storefront URL |

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

[basicAuth](../../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **storefrontUrlGet**
> \Swagger\Client\Model\InlineResponse2001 storefrontUrlGet($type, $id, $lang)

Returns a Storefront URL

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
// Configure HTTP basic authorization: basicAuth
$config = Swagger\Client\Configuration::getDefaultConfiguration()
              ->setUsername('YOUR_USERNAME')
              ->setPassword('YOUR_PASSWORD');


$apiInstance = new Swagger\Client\Api\MappingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$type = "type_example"; // string | Page Type
$id = "id_example"; // string | Unique Identifier
$lang = "lang_example"; // string | The language to localize the label

try {
    $result = $apiInstance->storefrontUrlGet($type, $id, $lang);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MappingApi->storefrontUrlGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type** | **string**| Page Type |
 **id** | **string**| Unique Identifier |
 **lang** | **string**| The language to localize the label | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2001**](../Model/InlineResponse2001.md)

### Authorization

[basicAuth](../../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

