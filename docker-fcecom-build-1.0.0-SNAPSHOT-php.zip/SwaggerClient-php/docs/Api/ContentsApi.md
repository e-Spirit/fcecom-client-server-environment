# Swagger\Client\ContentsApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**contentContentIdDelete**](ContentsApi.md#contentcontentiddelete) | **DELETE** /content/{contentId} | Rename and/or move a Content Page
[**contentContentIdPut**](ContentsApi.md#contentcontentidput) | **PUT** /content/{contentId} | Rename and/or move a Content Page
[**contentPost**](ContentsApi.md#contentpost) | **POST** /content | Create a new Content Page
[**contentsContentIdsGet**](ContentsApi.md#contentscontentidsget) | **GET** /contents/{contentIds} | Returns a list of Content Pages by IDs
[**contentsGet**](ContentsApi.md#contentsget) | **GET** /contents | Returns a list of Content Pages
[**contentsHead**](ContentsApi.md#contentshead) | **HEAD** /contents | Supports Content Report if exists

# **contentContentIdDelete**
> contentContentIdDelete($content_id, $lang)

Rename and/or move a Content Page

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
// Configure HTTP basic authorization: basicAuth
$config = Swagger\Client\Configuration::getDefaultConfiguration()
              ->setUsername('YOUR_USERNAME')
              ->setPassword('YOUR_PASSWORD');


$apiInstance = new Swagger\Client\Api\ContentsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$content_id = "content_id_example"; // string | 
$lang = "lang_example"; // string | The language to localize the label

try {
    $apiInstance->contentContentIdDelete($content_id, $lang);
} catch (Exception $e) {
    echo 'Exception when calling ContentsApi->contentContentIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **content_id** | **string**|  |
 **lang** | **string**| The language to localize the label | [optional]

### Return type

void (empty response body)

### Authorization

[basicAuth](../../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **contentContentIdPut**
> contentContentIdPut($body, $content_id, $lang)

Rename and/or move a Content Page

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
// Configure HTTP basic authorization: basicAuth
$config = Swagger\Client\Configuration::getDefaultConfiguration()
              ->setUsername('YOUR_USERNAME')
              ->setPassword('YOUR_PASSWORD');


$apiInstance = new Swagger\Client\Api\ContentsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\Content(); // \Swagger\Client\Model\Content | 
$content_id = "content_id_example"; // string | 
$lang = "lang_example"; // string | The language to localize the label

try {
    $apiInstance->contentContentIdPut($body, $content_id, $lang);
} catch (Exception $e) {
    echo 'Exception when calling ContentsApi->contentContentIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\Content**](../Model/Content.md)|  |
 **content_id** | **string**|  |
 **lang** | **string**| The language to localize the label | [optional]

### Return type

void (empty response body)

### Authorization

[basicAuth](../../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **contentPost**
> \Swagger\Client\Model\InlineResponse200 contentPost($body, $lang)

Create a new Content Page

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
// Configure HTTP basic authorization: basicAuth
$config = Swagger\Client\Configuration::getDefaultConfiguration()
              ->setUsername('YOUR_USERNAME')
              ->setPassword('YOUR_PASSWORD');


$apiInstance = new Swagger\Client\Api\ContentsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\Content(); // \Swagger\Client\Model\Content | 
$lang = "lang_example"; // string | The language to localize the label

try {
    $result = $apiInstance->contentPost($body, $lang);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ContentsApi->contentPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\Content**](../Model/Content.md)|  |
 **lang** | **string**| The language to localize the label | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

[basicAuth](../../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **contentsContentIdsGet**
> \Swagger\Client\Model\Content[] contentsContentIdsGet($content_ids, $lang)

Returns a list of Content Pages by IDs

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
// Configure HTTP basic authorization: basicAuth
$config = Swagger\Client\Configuration::getDefaultConfiguration()
              ->setUsername('YOUR_USERNAME')
              ->setPassword('YOUR_PASSWORD');


$apiInstance = new Swagger\Client\Api\ContentsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$content_ids = array("content_ids_example"); // string[] | Get one or more Content Pages by content.id (comma-separated)
$lang = "lang_example"; // string | The language to localize the label

try {
    $result = $apiInstance->contentsContentIdsGet($content_ids, $lang);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ContentsApi->contentsContentIdsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **content_ids** | [**string[]**](../Model/string.md)| Get one or more Content Pages by content.id (comma-separated) |
 **lang** | **string**| The language to localize the label | [optional]

### Return type

[**\Swagger\Client\Model\Content[]**](../Model/Content.md)

### Authorization

[basicAuth](../../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **contentsGet**
> \Swagger\Client\Model\Content[] contentsGet($q, $lang, $page)

Returns a list of Content Pages

A pageable list of Content Pages. Could be filtered.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
// Configure HTTP basic authorization: basicAuth
$config = Swagger\Client\Configuration::getDefaultConfiguration()
              ->setUsername('YOUR_USERNAME')
              ->setPassword('YOUR_PASSWORD');


$apiInstance = new Swagger\Client\Api\ContentsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$q = "q_example"; // string | Fulltext search query string
$lang = "lang_example"; // string | The language to localize the label
$page = 1; // int | Specific result page

try {
    $result = $apiInstance->contentsGet($q, $lang, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ContentsApi->contentsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **string**| Fulltext search query string | [optional]
 **lang** | **string**| The language to localize the label | [optional]
 **page** | **int**| Specific result page | [optional] [default to 1]

### Return type

[**\Swagger\Client\Model\Content[]**](../Model/Content.md)

### Authorization

[basicAuth](../../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **contentsHead**
> contentsHead()

Supports Content Report if exists

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
// Configure HTTP basic authorization: basicAuth
$config = Swagger\Client\Configuration::getDefaultConfiguration()
              ->setUsername('YOUR_USERNAME')
              ->setPassword('YOUR_PASSWORD');


$apiInstance = new Swagger\Client\Api\ContentsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $apiInstance->contentsHead();
} catch (Exception $e) {
    echo 'Exception when calling ContentsApi->contentsHead: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[basicAuth](../../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

