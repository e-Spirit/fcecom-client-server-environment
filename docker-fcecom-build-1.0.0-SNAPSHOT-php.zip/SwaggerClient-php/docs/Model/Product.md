# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**extract** | **string** | Product Extract | [optional] 
**image** | **string** | Image URL | [optional] 
**thumbnail** | **string** | Thumbnail URL | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

