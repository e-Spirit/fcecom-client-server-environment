# Content

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**template** | **string** |  | 
**visible** | **bool** |  | [optional] 
**label** | **string** |  | 
**parent_id** | **string** |  | [optional] 
**next_sibling_id** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

