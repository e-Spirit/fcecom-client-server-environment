# FirstSpiritConnectForECommerceBridgeApi.ProductsApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productsGet**](ProductsApi.md#productsGet) | **GET** /products | Returns a list of Products
[**productsProductIdsGet**](ProductsApi.md#productsProductIdsGet) | **GET** /products/{productIds} | Returns a list of Products by IDs

<a name="productsGet"></a>
# **productsGet**
> [Product] productsGet(opts)

Returns a list of Products

A pageable list of products. Could be filtered.

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.ProductsApi();
let opts = { 
  'categoryId': "categoryId_example", // String | Filter by category.id
  'q': "q_example", // String | Fulltext search query string
  'lang': "lang_example", // String | The language to localize the label
  'page': 1 // Number | Specific result page
};
apiInstance.productsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **String**| Filter by category.id | [optional] 
 **q** | **String**| Fulltext search query string | [optional] 
 **lang** | **String**| The language to localize the label | [optional] 
 **page** | **Number**| Specific result page | [optional] [default to 1]

### Return type

[**[Product]**](Product.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="productsProductIdsGet"></a>
# **productsProductIdsGet**
> [Product] productsProductIdsGet(productIds, opts)

Returns a list of Products by IDs

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.ProductsApi();
let productIds = ["productIds_example"]; // [String] | Get one or more Products by product.id (comma-separated)
let opts = { 
  'lang': "lang_example" // String | The language to localize the label
};
apiInstance.productsProductIdsGet(productIds, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productIds** | [**[String]**](String.md)| Get one or more Products by product.id (comma-separated) | 
 **lang** | **String**| The language to localize the label | [optional] 

### Return type

[**[Product]**](Product.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

