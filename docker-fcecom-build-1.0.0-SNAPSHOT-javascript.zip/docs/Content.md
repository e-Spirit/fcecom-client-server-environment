# FirstSpiritConnectForECommerceBridgeApi.Content

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**template** | **String** |  | 
**visible** | **Boolean** |  | [optional] 
**label** | **String** |  | 
**parentId** | **String** |  | [optional] 
**nextSiblingId** | **String** |  | [optional] 
