# FirstSpiritConnectForECommerceBridgeApi.MappingApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**lookupUrlGet**](MappingApi.md#lookupUrlGet) | **GET** /lookup-url | Returns an Identifier for a given Storefront URL
[**storefrontUrlGet**](MappingApi.md#storefrontUrlGet) | **GET** /storefront-url | Returns a Storefront URL

<a name="lookupUrlGet"></a>
# **lookupUrlGet**
> InlineResponse200 lookupUrlGet(url)

Returns an Identifier for a given Storefront URL

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.MappingApi();
let url = "url_example"; // String | A Storefront URL

apiInstance.lookupUrlGet(url, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **url** | **String**| A Storefront URL | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="storefrontUrlGet"></a>
# **storefrontUrlGet**
> InlineResponse2001 storefrontUrlGet(type, id, opts)

Returns a Storefront URL

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.MappingApi();
let type = "type_example"; // String | Page Type
let id = "id_example"; // String | Unique Identifier
let opts = { 
  'lang': "lang_example" // String | The language to localize the label
};
apiInstance.storefrontUrlGet(type, id, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type** | **String**| Page Type | 
 **id** | **String**| Unique Identifier | 
 **lang** | **String**| The language to localize the label | [optional] 

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

