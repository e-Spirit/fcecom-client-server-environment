# FirstSpiritConnectForECommerceBridgeApi.Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**children** | [**[Category]**](Category.md) |  | [optional] 
