# FirstSpiritConnectForECommerceBridgeApi.ContentsApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**contentContentIdDelete**](ContentsApi.md#contentContentIdDelete) | **DELETE** /content/{contentId} | Rename and/or move a Content Page
[**contentContentIdPut**](ContentsApi.md#contentContentIdPut) | **PUT** /content/{contentId} | Rename and/or move a Content Page
[**contentPost**](ContentsApi.md#contentPost) | **POST** /content | Create a new Content Page
[**contentsContentIdsGet**](ContentsApi.md#contentsContentIdsGet) | **GET** /contents/{contentIds} | Returns a list of Content Pages by IDs
[**contentsGet**](ContentsApi.md#contentsGet) | **GET** /contents | Returns a list of Content Pages
[**contentsHead**](ContentsApi.md#contentsHead) | **HEAD** /contents | Supports Content Report if exists

<a name="contentContentIdDelete"></a>
# **contentContentIdDelete**
> contentContentIdDelete(contentId, opts)

Rename and/or move a Content Page

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.ContentsApi();
let contentId = "contentId_example"; // String | 
let opts = { 
  'lang': "lang_example" // String | The language to localize the label
};
apiInstance.contentContentIdDelete(contentId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **contentId** | **String**|  | 
 **lang** | **String**| The language to localize the label | [optional] 

### Return type

null (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="contentContentIdPut"></a>
# **contentContentIdPut**
> contentContentIdPut(body, contentId, opts)

Rename and/or move a Content Page

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.ContentsApi();
let body = new FirstSpiritConnectForECommerceBridgeApi.Content(); // Content | 
let contentId = "contentId_example"; // String | 
let opts = { 
  'lang': "lang_example" // String | The language to localize the label
};
apiInstance.contentContentIdPut(body, contentId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Content**](Content.md)|  | 
 **contentId** | **String**|  | 
 **lang** | **String**| The language to localize the label | [optional] 

### Return type

null (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="contentPost"></a>
# **contentPost**
> InlineResponse200 contentPost(body, opts)

Create a new Content Page

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.ContentsApi();
let body = new FirstSpiritConnectForECommerceBridgeApi.Content(); // Content | 
let opts = { 
  'lang': "lang_example" // String | The language to localize the label
};
apiInstance.contentPost(body, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Content**](Content.md)|  | 
 **lang** | **String**| The language to localize the label | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="contentsContentIdsGet"></a>
# **contentsContentIdsGet**
> [Content] contentsContentIdsGet(contentIds, opts)

Returns a list of Content Pages by IDs

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.ContentsApi();
let contentIds = ["contentIds_example"]; // [String] | Get one or more Content Pages by content.id (comma-separated)
let opts = { 
  'lang': "lang_example" // String | The language to localize the label
};
apiInstance.contentsContentIdsGet(contentIds, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **contentIds** | [**[String]**](String.md)| Get one or more Content Pages by content.id (comma-separated) | 
 **lang** | **String**| The language to localize the label | [optional] 

### Return type

[**[Content]**](Content.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="contentsGet"></a>
# **contentsGet**
> [Content] contentsGet(opts)

Returns a list of Content Pages

A pageable list of Content Pages. Could be filtered.

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.ContentsApi();
let opts = { 
  'q': "q_example", // String | Fulltext search query string
  'lang': "lang_example", // String | The language to localize the label
  'page': 1 // Number | Specific result page
};
apiInstance.contentsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **String**| Fulltext search query string | [optional] 
 **lang** | **String**| The language to localize the label | [optional] 
 **page** | **Number**| Specific result page | [optional] [default to 1]

### Return type

[**[Content]**](Content.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="contentsHead"></a>
# **contentsHead**
> contentsHead()

Supports Content Report if exists

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.ContentsApi();
apiInstance.contentsHead((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

