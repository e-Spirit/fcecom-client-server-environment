# FirstSpiritConnectForECommerceBridgeApi.Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**extract** | **String** | Product Extract | [optional] 
**image** | **String** | Image URL | [optional] 
**thumbnail** | **String** | Thumbnail URL | [optional] 
