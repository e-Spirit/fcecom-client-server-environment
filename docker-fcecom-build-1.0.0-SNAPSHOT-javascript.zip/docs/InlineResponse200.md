# FirstSpiritConnectForECommerceBridgeApi.InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**lang** | **String** |  | [optional] 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `category` (value: `"category"`)
* `product` (value: `"product"`)
* `content` (value: `"content"`)

