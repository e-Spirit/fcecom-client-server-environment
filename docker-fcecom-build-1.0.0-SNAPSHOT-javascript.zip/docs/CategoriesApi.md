# FirstSpiritConnectForECommerceBridgeApi.CategoriesApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categoriesGet**](CategoriesApi.md#categoriesGet) | **GET** /categories | Returns the Category Tree

<a name="categoriesGet"></a>
# **categoriesGet**
> [Category] categoriesGet(opts)

Returns the Category Tree

All categories in tree format.

### Example
```javascript
import {FirstSpiritConnectForECommerceBridgeApi} from 'first_spirit_connect_for_e_commerce___bridge_api';
let defaultClient = FirstSpiritConnectForECommerceBridgeApi.ApiClient.instance;
// Configure HTTP basic authorization: basicAuth
let basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

let apiInstance = new FirstSpiritConnectForECommerceBridgeApi.CategoriesApi();
let opts = { 
  'lang': "lang_example" // String | The language to localize the label
};
apiInstance.categoriesGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lang** | **String**| The language to localize the label | [optional] 

### Return type

[**[Category]**](Category.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

