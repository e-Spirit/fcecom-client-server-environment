'use strict';


/**
 * Returns the Category Tree
 * All categories in tree format.
 *
 * lang String The language to localize the label (optional)
 * returns List
 **/
exports.categoriesGET = function(lang) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "id" : "category-1",
  "label" : "Category 1",
  "children" : [ {
    "id" : "category-1-1",
    "label" : "Category 1.1"
  }, {
    "id" : "category-1-2",
    "label" : "Category 1.1",
    "children" : [ {
      "id" : "category-1-2-1",
      "label" : "Category 1.2.1"
    } ]
  } ]
}, {
  "id" : "category-1",
  "label" : "Category 1",
  "children" : [ {
    "id" : "category-1-1",
    "label" : "Category 1.1"
  }, {
    "id" : "category-1-2",
    "label" : "Category 1.1",
    "children" : [ {
      "id" : "category-1-2-1",
      "label" : "Category 1.2.1"
    } ]
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

