'use strict';


/**
 * Returns a list of Products
 * A pageable list of products. Could be filtered.
 *
 * categoryId String Filter by category.id (optional)
 * q String Fulltext search query string (optional)
 * lang String The language to localize the label (optional)
 * page Integer Specific result page (optional)
 * returns List
 **/
exports.productsGET = function(categoryId,q,lang,page) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ "", "" ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns a list of Products by IDs
 *
 * productIds List Get one or more Products by product.id (comma-separated)
 * lang String The language to localize the label (optional)
 * returns List
 **/
exports.productsProductIdsGET = function(productIds,lang) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ "", "" ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

