'use strict';


/**
 * Rename and/or move a Content Page
 *
 * contentId String 
 * lang String The language to localize the label (optional)
 * no response value expected for this operation
 **/
exports.contentContentIdDELETE = function(contentId,lang) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Rename and/or move a Content Page
 *
 * body Content 
 * lang String The language to localize the label (optional)
 * contentId String 
 * no response value expected for this operation
 **/
exports.contentContentIdPUT = function(body,lang,contentId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create a new Content Page
 *
 * body Content 
 * lang String The language to localize the label (optional)
 * returns inline_response_200
 **/
exports.contentPOST = function(body,lang) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns a list of Content Pages by IDs
 *
 * contentIds List Get one or more Content Pages by content.id (comma-separated)
 * lang String The language to localize the label (optional)
 * returns List
 **/
exports.contentsContentIdsGET = function(contentIds,lang) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "template" : "template",
  "visible" : true,
  "nextSiblingId" : "nextSiblingId",
  "label" : "label",
  "parentId" : "parentId"
}, {
  "template" : "template",
  "visible" : true,
  "nextSiblingId" : "nextSiblingId",
  "label" : "label",
  "parentId" : "parentId"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns a list of Content Pages
 * A pageable list of Content Pages. Could be filtered.
 *
 * q String Fulltext search query string (optional)
 * lang String The language to localize the label (optional)
 * page Integer Specific result page (optional)
 * returns List
 **/
exports.contentsGET = function(q,lang,page) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "template" : "template",
  "visible" : true,
  "nextSiblingId" : "nextSiblingId",
  "label" : "label",
  "parentId" : "parentId"
}, {
  "template" : "template",
  "visible" : true,
  "nextSiblingId" : "nextSiblingId",
  "label" : "label",
  "parentId" : "parentId"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Supports Content Report if exists
 *
 * no response value expected for this operation
 **/
exports.contentsHEAD = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

