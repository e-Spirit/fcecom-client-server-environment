'use strict';


/**
 * Returns an Identifier for a given Storefront URL
 *
 * url String A Storefront URL
 * returns inline_response_200
 **/
exports.lookup_urlGET = function(url) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Returns a Storefront URL
 *
 * type String Page Type
 * id String Unique Identifier
 * lang String The language to localize the label (optional)
 * returns inline_response_200_1
 **/
exports.storefront_urlGET = function(type,id,lang) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

