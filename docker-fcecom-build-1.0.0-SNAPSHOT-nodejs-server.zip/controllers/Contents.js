'use strict';

var utils = require('../utils/writer.js');
var Contents = require('../service/ContentsService');

module.exports.contentContentIdDELETE = function contentContentIdDELETE (req, res, next, contentId, lang) {
  Contents.contentContentIdDELETE(contentId, lang)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.contentContentIdPUT = function contentContentIdPUT (req, res, next, body, lang, contentId) {
  Contents.contentContentIdPUT(body, lang, contentId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.contentPOST = function contentPOST (req, res, next, body, lang) {
  Contents.contentPOST(body, lang)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.contentsContentIdsGET = function contentsContentIdsGET (req, res, next, contentIds, lang) {
  Contents.contentsContentIdsGET(contentIds, lang)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.contentsGET = function contentsGET (req, res, next, q, lang, page) {
  Contents.contentsGET(q, lang, page)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.contentsHEAD = function contentsHEAD (req, res, next) {
  Contents.contentsHEAD()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
