'use strict';

var utils = require('../utils/writer.js');
var Mapping = require('../service/MappingService');

module.exports.lookup_urlGET = function lookup_urlGET (req, res, next, url) {
  Mapping.lookup_urlGET(url)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.storefront_urlGET = function storefront_urlGET (req, res, next, type, id, lang) {
  Mapping.storefront_urlGET(type, id, lang)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
