# ContentsApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**contentContentIdDelete**](ContentsApi.md#contentContentIdDelete) | **DELETE** /content/{contentId} | Rename and/or move a Content Page
[**contentContentIdPut**](ContentsApi.md#contentContentIdPut) | **PUT** /content/{contentId} | Rename and/or move a Content Page
[**contentPost**](ContentsApi.md#contentPost) | **POST** /content | Create a new Content Page
[**contentsContentIdsGet**](ContentsApi.md#contentsContentIdsGet) | **GET** /contents/{contentIds} | Returns a list of Content Pages by IDs
[**contentsGet**](ContentsApi.md#contentsGet) | **GET** /contents | Returns a list of Content Pages
[**contentsHead**](ContentsApi.md#contentsHead) | **HEAD** /contents | Supports Content Report if exists

<a name="contentContentIdDelete"></a>
# **contentContentIdDelete**
> contentContentIdDelete(contentId, lang)

Rename and/or move a Content Page

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ContentsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

ContentsApi apiInstance = new ContentsApi();
String contentId = "contentId_example"; // String | 
String lang = "lang_example"; // String | The language to localize the label
try {
    apiInstance.contentContentIdDelete(contentId, lang);
} catch (ApiException e) {
    System.err.println("Exception when calling ContentsApi#contentContentIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **contentId** | **String**|  |
 **lang** | **String**| The language to localize the label | [optional]

### Return type

null (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="contentContentIdPut"></a>
# **contentContentIdPut**
> contentContentIdPut(body, contentId, lang)

Rename and/or move a Content Page

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ContentsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

ContentsApi apiInstance = new ContentsApi();
Content body = new Content(); // Content | 
String contentId = "contentId_example"; // String | 
String lang = "lang_example"; // String | The language to localize the label
try {
    apiInstance.contentContentIdPut(body, contentId, lang);
} catch (ApiException e) {
    System.err.println("Exception when calling ContentsApi#contentContentIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Content**](Content.md)|  |
 **contentId** | **String**|  |
 **lang** | **String**| The language to localize the label | [optional]

### Return type

null (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="contentPost"></a>
# **contentPost**
> InlineResponse200 contentPost(body, lang)

Create a new Content Page

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ContentsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

ContentsApi apiInstance = new ContentsApi();
Content body = new Content(); // Content | 
String lang = "lang_example"; // String | The language to localize the label
try {
    InlineResponse200 result = apiInstance.contentPost(body, lang);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ContentsApi#contentPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Content**](Content.md)|  |
 **lang** | **String**| The language to localize the label | [optional]

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="contentsContentIdsGet"></a>
# **contentsContentIdsGet**
> List&lt;Content&gt; contentsContentIdsGet(contentIds, lang)

Returns a list of Content Pages by IDs

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ContentsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

ContentsApi apiInstance = new ContentsApi();
List<String> contentIds = Arrays.asList("contentIds_example"); // List<String> | Get one or more Content Pages by content.id (comma-separated)
String lang = "lang_example"; // String | The language to localize the label
try {
    List<Content> result = apiInstance.contentsContentIdsGet(contentIds, lang);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ContentsApi#contentsContentIdsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **contentIds** | [**List&lt;String&gt;**](String.md)| Get one or more Content Pages by content.id (comma-separated) |
 **lang** | **String**| The language to localize the label | [optional]

### Return type

[**List&lt;Content&gt;**](Content.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="contentsGet"></a>
# **contentsGet**
> List&lt;Content&gt; contentsGet(q, lang, page)

Returns a list of Content Pages

A pageable list of Content Pages. Could be filtered.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ContentsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

ContentsApi apiInstance = new ContentsApi();
String q = "q_example"; // String | Fulltext search query string
String lang = "lang_example"; // String | The language to localize the label
Integer page = 1; // Integer | Specific result page
try {
    List<Content> result = apiInstance.contentsGet(q, lang, page);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ContentsApi#contentsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **String**| Fulltext search query string | [optional]
 **lang** | **String**| The language to localize the label | [optional]
 **page** | **Integer**| Specific result page | [optional] [default to 1] [enum: ]

### Return type

[**List&lt;Content&gt;**](Content.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="contentsHead"></a>
# **contentsHead**
> contentsHead()

Supports Content Report if exists

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ContentsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

ContentsApi apiInstance = new ContentsApi();
try {
    apiInstance.contentsHead();
} catch (ApiException e) {
    System.err.println("Exception when calling ContentsApi#contentsHead");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

