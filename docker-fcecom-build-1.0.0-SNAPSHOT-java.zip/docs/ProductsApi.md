# ProductsApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productsGet**](ProductsApi.md#productsGet) | **GET** /products | Returns a list of Products
[**productsProductIdsGet**](ProductsApi.md#productsProductIdsGet) | **GET** /products/{productIds} | Returns a list of Products by IDs

<a name="productsGet"></a>
# **productsGet**
> List&lt;Product&gt; productsGet(categoryId, q, lang, page)

Returns a list of Products

A pageable list of products. Could be filtered.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

ProductsApi apiInstance = new ProductsApi();
String categoryId = "categoryId_example"; // String | Filter by category.id
String q = "q_example"; // String | Fulltext search query string
String lang = "lang_example"; // String | The language to localize the label
Integer page = 1; // Integer | Specific result page
try {
    List<Product> result = apiInstance.productsGet(categoryId, q, lang, page);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#productsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **String**| Filter by category.id | [optional]
 **q** | **String**| Fulltext search query string | [optional]
 **lang** | **String**| The language to localize the label | [optional]
 **page** | **Integer**| Specific result page | [optional] [default to 1] [enum: ]

### Return type

[**List&lt;Product&gt;**](Product.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="productsProductIdsGet"></a>
# **productsProductIdsGet**
> List&lt;Product&gt; productsProductIdsGet(productIds, lang)

Returns a list of Products by IDs

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

ProductsApi apiInstance = new ProductsApi();
List<String> productIds = Arrays.asList("productIds_example"); // List<String> | Get one or more Products by product.id (comma-separated)
String lang = "lang_example"; // String | The language to localize the label
try {
    List<Product> result = apiInstance.productsProductIdsGet(productIds, lang);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#productsProductIdsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productIds** | [**List&lt;String&gt;**](String.md)| Get one or more Products by product.id (comma-separated) |
 **lang** | **String**| The language to localize the label | [optional]

### Return type

[**List&lt;Product&gt;**](Product.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

