# MappingApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**lookupUrlGet**](MappingApi.md#lookupUrlGet) | **GET** /lookup-url | Returns an Identifier for a given Storefront URL
[**storefrontUrlGet**](MappingApi.md#storefrontUrlGet) | **GET** /storefront-url | Returns a Storefront URL

<a name="lookupUrlGet"></a>
# **lookupUrlGet**
> InlineResponse200 lookupUrlGet(url)

Returns an Identifier for a given Storefront URL

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.MappingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

MappingApi apiInstance = new MappingApi();
String url = "url_example"; // String | A Storefront URL
try {
    InlineResponse200 result = apiInstance.lookupUrlGet(url);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MappingApi#lookupUrlGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **url** | **String**| A Storefront URL |

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="storefrontUrlGet"></a>
# **storefrontUrlGet**
> InlineResponse2001 storefrontUrlGet(type, id, lang)

Returns a Storefront URL

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.MappingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

MappingApi apiInstance = new MappingApi();
String type = "type_example"; // String | Page Type
String id = "id_example"; // String | Unique Identifier
String lang = "lang_example"; // String | The language to localize the label
try {
    InlineResponse2001 result = apiInstance.storefrontUrlGet(type, id, lang);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MappingApi#storefrontUrlGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type** | **String**| Page Type | [enum: category, product, content]
 **id** | **String**| Unique Identifier |
 **lang** | **String**| The language to localize the label | [optional]

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

