# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**children** | [**List&lt;Category&gt;**](Category.md) |  |  [optional]
